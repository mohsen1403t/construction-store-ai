import Link from 'next/link';
export default function ProductCard({ product }) {
  return (
    <div className="border rounded p-4">
      <img src={product.images?.[0] || '/placeholder.png'} alt={product.name} className="h-40 w-full object-cover" />
      <h3 className="text-lg font-semibold mt-2">{product.name}</h3>
      <p className="text-sm text-gray-600">{product.shortDescription}</p>
      <div className="flex items-center justify-between mt-3">
        <span className="font-bold">{product.price} تومان</span>
        <Link href={`/shop/${product._id}`} className="bg-blue-600 text-white px-3 py-1 rounded">مشاهده</Link>
      </div>
    </div>
  );
}
