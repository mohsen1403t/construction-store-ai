import Link from 'next/link';
export default function Home() {
  return (
    <main className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">ساخت و تجهیز کامل ساختمان</h1>
      <p className="mb-6">از مصالح تا اجرا — همه چیز در یک فروشگاه</p>
      <div className="space-x-2">
        <Link href='/shop' className="px-4 py-2 bg-blue-600 text-white rounded">فروشگاه</Link>
        <Link href='/services' className="px-4 py-2 border rounded">خدمات</Link>
      </div>
    </main>
  );
}
