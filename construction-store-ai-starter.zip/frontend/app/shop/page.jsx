import ProductCard from '../../components/ProductCard';
import { useEffect, useState } from 'react';
import { fetchProducts } from '../../lib/api';

export default function ShopPage() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    fetchProducts().then(setProducts).catch(console.error);
  }, []);
  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">فروشگاه</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map(p => <ProductCard key={p._id} product={p} />)}
      </div>
    </div>
  );
}
