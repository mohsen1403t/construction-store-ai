import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  slug: { type: String },
  shortDescription: { type: String },
  description: { type: String },
  price: { type: Number, required: true },
  brand: { type: String },
  category: { type: String },
  stock: { type: Number, default: 0 },
  images: [String],
  attributes: { type: Object, default: {} },
  bestseller: { type: Boolean, default: false }
}, { timestamps: true });

const Product = mongoose.models.Product || mongoose.model('Product', productSchema);
export default Product;
